import  xml.etree.ElementTree as ET
import unittest


class c(unittest.TestCase):
	def test_positive(self):
		a=a1()
		a.input()
		a.bsearch(0,len(a.array)-1)		
		self.assertEqual(5,a.ans)
		print a.ans
		
class a1():
	def input(self):
		self.array=[]
		root=ET.parse('input.xml').getroot()
		d=root.findall('num')
		for i in range(0,int(root.find('len').text)):
			self.array.append(int(d[i].text))
		self.key=int(root.find('key').text)
		self.array.sort()
		
		self.sort()
		print self.array

	def sort(self):
		for i in range(0,len(self.array)-1):
			for j in range(i+1,len(self.array)-1):
				if self.array[i]>self.array[j]:
					temp=self.array[i]					
					self.array[i]=self.array[j]
					self.array[j]=temp
		print self.array

	def bsearch(self,l,r):
		if l<=r:
			mid=(l+r)/2
			if self.array[mid]==self.key:
				self.ans=mid
			elif self.array[mid]<self.key:
				self.bsearch(mid+1,r)
			else:
				self.bsearch(l,mid-1)	
		else:
			self.ans=-1
unittest.main()
