from bottle import *
from boo import booths

@route('/')
def home():
	return template('index.html',result=None)


@post('/add')
def add():
	result=booths(request.forms.get('a1'),request.forms.get('b1'))
	return template('index.html',result=result)
run(host='127.0.0.1',port=5003)
