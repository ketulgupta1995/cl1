bits=8
length=(bits*2)+1
def dtob(num):
	a=[0 for i in range(8)]
	i=bits-1
	while(num!=0) and i>=0 :
		a[i]=num%2
		num=num/2
		i-=1
	return a

def btod(a):
	neg=0
	print a
	if a[0]==1:
		neg=1
		i=len(a)-1
		while(i>=0):
			if a[i]==1:
				a[i]=0
			else:
				a[i]=1
			i-=1
		i=len(a)-1
		while(i>=0):
			if a[i]==1:
				a[i]=0
			else:
				a[i]=1
				break
			i-=1
	print a
	
	num=0
	i=len(a)-1
	j=0
	while(i>=0):
		num+=a[i]*pow(2,j)
		j+=1
		i-=1
	if neg==1:	
		return -1*num
	return num

def arshift(a):
	i=len(a)-1
	while(i>=1):
		a[i]=a[i-1]
		i-=1
	return a

def addbinary(a,b):
	i=len(a)-1
	carry=0
	c=[0 for i in range(len(a))]	
	while(i>=0):
		temp=a[i]+b[i]+carry
		c[i]=temp%2
		carry=temp/2
		i-=1
	return c

def booths(a1,b1):
	a1=int(a1)
	b1=int(b1)
	a=dtob(a1)
	acomp=dtob(-a1)
	print a,acomp
	b=dtob(b1)
	A=[0 for i in range(length)]
	S=[0  for i in range(length)]
	P=[0 for i in range(length)]

	i=0
	while(i<bits):
		A[i]=a[i]
		S[i]=acomp[i]
		P[i+bits]=b[i]
		i+=1
	print A,S,P
	
	i=bits
	while(i>0):
		if P[-1]==0 and P[-2]==0 or P[-1]==1 and P[-2]==1:
			P=arshift(P)
		elif P[-1]==0 and P[-2]==1:
			P=addbinary(P,S)
			P=arshift(P)
		elif P[-1]==1 and P[-2]==0:
			P=addbinary(P,A)
			P=arshift(P)
		i-=1
	return btod(P[:-1])
#booths(-8,5)






'''
dtob(5)
btod([0,0,0,1,0,0,0,0])
arshift([1,0,0,1,1,0,0,0])
addbinary([0,0,0,1,1,0,0,0],[0,0,0,1,0,0,0,0])
'''
