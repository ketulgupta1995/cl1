import threading
import time

def partition(a,l,r):
	pivot=a[l]
	i=l+1
	j=r
	done=False
	while not done:
		while(i<=j and a[i]<pivot):
			i+=1
		while(j>=i and a[j]>=pivot):
			j-=1
		if j<i:
			done=True
		else:
			a[j],a[i]=a[i],a[j]
	a[l],a[j]=a[j],a[l]
	return j


def qsort(a,l,r):
	if(l<r):
		mid=partition(a,l,r)
		print "sorting ",l,mid-1
		print "sorting ",mid+1,r	
		t1=threading.Thread(target=qsort,args=(a,l,mid-1))
		print t1.getName()
		t2=threading.Thread(target=qsort,args=(a,mid+1,r))
		print t2.getName()
		t1.start()
		t2.start()
		t1.join()
		t2.join()

a=[4,5,6,1,2,9,8,22,0,55,99,66,22,33,3]
print a
qsort(a,0,14)
print a



