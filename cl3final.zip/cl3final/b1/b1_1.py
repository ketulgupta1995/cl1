def isattack(b,r,c):
	# quuens in same column above rows
	for i in range(r):
		if b[i][c]==1:
			return True
	#queens in left and above
	i=r-1
	j=c-1
	while i>=0 and j>=0:
		if b[i][j]==1:
			return True
		i-=1
		j-=1
	#quuens in right and above
	i=r-1
	j=c+1
	while i>=0 and j<8:
		if b[i][j]==1:
			return True
		i-=1
		j+=1
	return False

def solve(b,row):
	i=0
	while i<8:
		if not isattack(b,row,i):
			#if completely solved	
			b[row][i]=1
			if row==7:
				return True
			#if not try to place next queen
			else:
				if solve(b,row+1):
					return True
			# if next postion not found try other postion
				else:
					b[row][i]=0
		i+=1
	if i==8:
		return False
					
	
def pb(b):
	for i in range(8):
		print b[i] 
def main():
	b=[[0 for i in range(8)] for i in range(8)]
	pb(b)

	firstq=int(input('Placeing first queen in column  '))
	b[0][firstq]=1
	pb( b)
	if solve(b,1)==True:
		print 'Soluntion posisble '
		pb( b)
	else:
		print 'no solution possible'

main()
